﻿Imports System.Resources

Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("라온툴즈 1.3.2.0")> 
<Assembly: AssemblyDescription("그리드 & 악성 프로그램 제거")> 
<Assembly: AssemblyCompany("라온피아")> 
<Assembly: AssemblyProduct("라온툴즈")> 
<Assembly: AssemblyCopyright("Copyright © 2013 Raonpia. All Rights Reserved.")> 
<Assembly: AssemblyTrademark("라온피아닷컴")> 

<Assembly: ComVisible(False)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("ac9030eb-8546-4d37-ae49-ac4924787602")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.3.2.0")> 
'<Assembly: AssemblyFileVersion("1.2.1.2")> 

<Assembly: NeutralResourcesLanguageAttribute("ko")> 