﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.btnDelGrid = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnVer = New System.Windows.Forms.Button()
        Me.btnList = New System.Windows.Forms.Button()
        Me.btnGoToWebsite = New System.Windows.Forms.Button()
        Me.btnShutdown = New System.Windows.Forms.Button()
        Me.btnInfo = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btnGoToBlog = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnDelGrid
        '
        Me.btnDelGrid.Font = New System.Drawing.Font("Gulim", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.btnDelGrid.Location = New System.Drawing.Point(34, 146)
        Me.btnDelGrid.Name = "btnDelGrid"
        Me.btnDelGrid.Size = New System.Drawing.Size(289, 38)
        Me.btnDelGrid.TabIndex = 0
        Me.btnDelGrid.Text = "그리드 && 악성 프로그램 제거"
        Me.btnDelGrid.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Gulim", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label1.Location = New System.Drawing.Point(48, 119)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(237, 13)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "원클릭 그리드 && 악성 프로그램 제거"
        '
        'btnVer
        '
        Me.btnVer.Image = Global.RaonTools.My.Resources.Resources.Version
        Me.btnVer.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnVer.Location = New System.Drawing.Point(291, 114)
        Me.btnVer.Name = "btnVer"
        Me.btnVer.Size = New System.Drawing.Size(49, 24)
        Me.btnVer.TabIndex = 7
        Me.btnVer.Text = "Ver"
        Me.btnVer.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnVer.UseVisualStyleBackColor = True
        '
        'btnList
        '
        Me.btnList.Font = New System.Drawing.Font("Gulim", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.btnList.Image = Global.RaonTools.My.Resources.Resources.list
        Me.btnList.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnList.Location = New System.Drawing.Point(34, 204)
        Me.btnList.Name = "btnList"
        Me.btnList.Size = New System.Drawing.Size(289, 38)
        Me.btnList.TabIndex = 2
        Me.btnList.Text = "그리드 && 악성 프로그램 목록"
        Me.btnList.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnList.UseVisualStyleBackColor = True
        '
        'btnGoToWebsite
        '
        Me.btnGoToWebsite.Image = Global.RaonTools.My.Resources.Resources.Website
        Me.btnGoToWebsite.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnGoToWebsite.Location = New System.Drawing.Point(94, 260)
        Me.btnGoToWebsite.Name = "btnGoToWebsite"
        Me.btnGoToWebsite.Size = New System.Drawing.Size(80, 24)
        Me.btnGoToWebsite.TabIndex = 4
        Me.btnGoToWebsite.Text = "웹사이트"
        Me.btnGoToWebsite.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnGoToWebsite.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnGoToWebsite.UseVisualStyleBackColor = True
        '
        'btnShutdown
        '
        Me.btnShutdown.Image = Global.RaonTools.My.Resources.Resources.Shutdown
        Me.btnShutdown.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnShutdown.Location = New System.Drawing.Point(267, 260)
        Me.btnShutdown.Name = "btnShutdown"
        Me.btnShutdown.Size = New System.Drawing.Size(80, 24)
        Me.btnShutdown.TabIndex = 6
        Me.btnShutdown.Text = "종료"
        Me.btnShutdown.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnShutdown.UseVisualStyleBackColor = True
        '
        'btnInfo
        '
        Me.btnInfo.Image = Global.RaonTools.My.Resources.Resources.Info
        Me.btnInfo.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnInfo.Location = New System.Drawing.Point(9, 260)
        Me.btnInfo.Name = "btnInfo"
        Me.btnInfo.Size = New System.Drawing.Size(80, 24)
        Me.btnInfo.TabIndex = 3
        Me.btnInfo.Text = "그리드??"
        Me.btnInfo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnInfo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnInfo.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.InitialImage = CType(resources.GetObject("PictureBox1.InitialImage"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(34, -1)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(289, 118)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 10
        Me.PictureBox1.TabStop = False
        '
        'btnGoToBlog
        '
        Me.btnGoToBlog.Image = Global.RaonTools.My.Resources.Resources.Website
        Me.btnGoToBlog.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnGoToBlog.Location = New System.Drawing.Point(181, 260)
        Me.btnGoToBlog.Name = "btnGoToBlog"
        Me.btnGoToBlog.Size = New System.Drawing.Size(80, 24)
        Me.btnGoToBlog.TabIndex = 5
        Me.btnGoToBlog.Text = "블로그"
        Me.btnGoToBlog.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnGoToBlog.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(356, 306)
        Me.Controls.Add(Me.btnGoToBlog)
        Me.Controls.Add(Me.btnVer)
        Me.Controls.Add(Me.btnList)
        Me.Controls.Add(Me.btnGoToWebsite)
        Me.Controls.Add(Me.btnShutdown)
        Me.Controls.Add(Me.btnInfo)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnDelGrid)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnDelGrid As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents btnInfo As System.Windows.Forms.Button
    Friend WithEvents btnShutdown As System.Windows.Forms.Button
    Friend WithEvents btnGoToWebsite As System.Windows.Forms.Button
    Friend WithEvents btnList As System.Windows.Forms.Button
    Friend WithEvents btnVer As System.Windows.Forms.Button
    Friend WithEvents btnGoToBlog As System.Windows.Forms.Button

End Class
