﻿Public Class frmListProgram
    Private Sub frmListProgram_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtBoxListProgram.Text = My.Resources.Program_List
    End Sub
End Class