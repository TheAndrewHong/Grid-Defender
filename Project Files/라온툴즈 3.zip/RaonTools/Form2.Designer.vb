﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmListProgram
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmListProgram))
        Me.txtBoxListProgram = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'txtBoxListProgram
        '
        Me.txtBoxListProgram.Dock = System.Windows.Forms.DockStyle.Fill
        Me.txtBoxListProgram.Location = New System.Drawing.Point(0, 0)
        Me.txtBoxListProgram.Multiline = True
        Me.txtBoxListProgram.Name = "txtBoxListProgram"
        Me.txtBoxListProgram.ReadOnly = True
        Me.txtBoxListProgram.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtBoxListProgram.Size = New System.Drawing.Size(668, 376)
        Me.txtBoxListProgram.TabIndex = 0
        '
        'frmListProgram
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(668, 376)
        Me.Controls.Add(Me.txtBoxListProgram)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmListProgram"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "프로그램 목록"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtBoxListProgram As System.Windows.Forms.TextBox
End Class
