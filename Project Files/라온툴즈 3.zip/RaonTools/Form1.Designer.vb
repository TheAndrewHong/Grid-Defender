﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.btnDelGrid = New System.Windows.Forms.Button()
        Me.btnDelTemp = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnVer = New System.Windows.Forms.Button()
        Me.btnList = New System.Windows.Forms.Button()
        Me.btnGoToWebsite = New System.Windows.Forms.Button()
        Me.btnShutdown = New System.Windows.Forms.Button()
        Me.btnInfo = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnDelGrid
        '
        Me.btnDelGrid.Font = New System.Drawing.Font("Gulim", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.btnDelGrid.Location = New System.Drawing.Point(47, 152)
        Me.btnDelGrid.Name = "btnDelGrid"
        Me.btnDelGrid.Size = New System.Drawing.Size(227, 38)
        Me.btnDelGrid.TabIndex = 0
        Me.btnDelGrid.Text = "1. 그리드 && 악성 프로그램 제거"
        Me.btnDelGrid.UseVisualStyleBackColor = True
        '
        'btnDelTemp
        '
        Me.btnDelTemp.Font = New System.Drawing.Font("Gulim", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.btnDelTemp.Location = New System.Drawing.Point(47, 207)
        Me.btnDelTemp.Name = "btnDelTemp"
        Me.btnDelTemp.Size = New System.Drawing.Size(227, 38)
        Me.btnDelTemp.TabIndex = 1
        Me.btnDelTemp.Text = "2. 라온툴즈 임시파일 삭제"
        Me.btnDelTemp.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Gulim", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label1.Location = New System.Drawing.Point(31, 122)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(190, 13)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "그리드 && 악성 프로그램 제거"
        '
        'btnVer
        '
        Me.btnVer.Image = Global.RaonTools.My.Resources.Resources.Version
        Me.btnVer.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnVer.Location = New System.Drawing.Point(240, 117)
        Me.btnVer.Name = "btnVer"
        Me.btnVer.Size = New System.Drawing.Size(49, 24)
        Me.btnVer.TabIndex = 12
        Me.btnVer.Text = "Ver"
        Me.btnVer.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnVer.UseVisualStyleBackColor = True
        '
        'btnList
        '
        Me.btnList.Font = New System.Drawing.Font("Gulim", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.btnList.Image = Global.RaonTools.My.Resources.Resources.list
        Me.btnList.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnList.Location = New System.Drawing.Point(47, 257)
        Me.btnList.Name = "btnList"
        Me.btnList.Size = New System.Drawing.Size(227, 38)
        Me.btnList.TabIndex = 11
        Me.btnList.Text = "프로그램 목록"
        Me.btnList.UseVisualStyleBackColor = True
        '
        'btnGoToWebsite
        '
        Me.btnGoToWebsite.Image = Global.RaonTools.My.Resources.Resources.Website
        Me.btnGoToWebsite.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnGoToWebsite.Location = New System.Drawing.Point(120, 307)
        Me.btnGoToWebsite.Name = "btnGoToWebsite"
        Me.btnGoToWebsite.Size = New System.Drawing.Size(81, 24)
        Me.btnGoToWebsite.TabIndex = 3
        Me.btnGoToWebsite.Text = "웹사이트"
        Me.btnGoToWebsite.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnGoToWebsite.UseVisualStyleBackColor = True
        '
        'btnShutdown
        '
        Me.btnShutdown.Image = Global.RaonTools.My.Resources.Resources.Shutdown
        Me.btnShutdown.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnShutdown.Location = New System.Drawing.Point(226, 307)
        Me.btnShutdown.Name = "btnShutdown"
        Me.btnShutdown.Size = New System.Drawing.Size(81, 24)
        Me.btnShutdown.TabIndex = 4
        Me.btnShutdown.Text = "종료"
        Me.btnShutdown.UseVisualStyleBackColor = True
        '
        'btnInfo
        '
        Me.btnInfo.Image = Global.RaonTools.My.Resources.Resources.Info
        Me.btnInfo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btnInfo.Location = New System.Drawing.Point(14, 307)
        Me.btnInfo.Name = "btnInfo"
        Me.btnInfo.Size = New System.Drawing.Size(81, 24)
        Me.btnInfo.TabIndex = 2
        Me.btnInfo.Text = "그리드??"
        Me.btnInfo.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.btnInfo.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.InitialImage = CType(resources.GetObject("PictureBox1.InitialImage"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(12, 8)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(293, 106)
        Me.PictureBox1.TabIndex = 10
        Me.PictureBox1.TabStop = False
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(320, 343)
        Me.Controls.Add(Me.btnVer)
        Me.Controls.Add(Me.btnList)
        Me.Controls.Add(Me.btnGoToWebsite)
        Me.Controls.Add(Me.btnShutdown)
        Me.Controls.Add(Me.btnInfo)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnDelTemp)
        Me.Controls.Add(Me.btnDelGrid)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "라온툴즈 v1.2.1.1"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnDelGrid As System.Windows.Forms.Button
    Friend WithEvents btnDelTemp As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents btnInfo As System.Windows.Forms.Button
    Friend WithEvents btnShutdown As System.Windows.Forms.Button
    Friend WithEvents btnGoToWebsite As System.Windows.Forms.Button
    Friend WithEvents btnList As System.Windows.Forms.Button
    Friend WithEvents btnVer As System.Windows.Forms.Button

End Class
