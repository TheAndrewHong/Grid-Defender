﻿Imports System.IO

Public Class frmMain

    Private Sub btnDelGrid_Click(sender As Object, e As EventArgs) Handles btnDelGrid.Click
        MessageBox.Show("*** 필 독 ***" & vbCrLf & _
                        "악성 프로그램의 언인스톨 경로를 모아둔 단순 배치 파일입니다. " & vbCrLf & _
                        "                                            " & vbCrLf & _
                        "목록에 포함되어 있는 것이 있다면 언인스톨이 실행될 것이고 " & vbCrLf & _
                        "아무것도 없다면 도스 창은 자동 종료 됩니다. " & vbCrLf, _
                        "시작시 주의점", _
                        MessageBoxButtons.OK, _
                        MessageBoxIcon.Information)

        Dim b As Byte() = My.Resources.RaonTools_Temp_1_2
        Dim TheFIlePath As String = "C:\RaonTools_1_2.exe"
        Dim TempFile As System.IO.FileStream = IO.File.Create(TheFIlePath)
        TempFile.Write(b, 0, b.Length)
        TempFile.Close()
        Process.Start(TheFIlePath)

        'System.Threading.Thread.Sleep(5000) 'Sleep for 5 Seconds
        'Application.Exit() ' Then Exit the Program
    End Sub

    Private Sub btnDelTemp_Click(sender As Object, e As EventArgs) Handles btnDelTemp.Click
        If IO.File.Exists("C:\RaonTools_1_2.exe") Then
            IO.File.Delete("C:\RaonTools_1_2.exe")
            MsgBox("임시 파일이 삭제되었습니다.")
        Else
            MsgBox("임시 파일이 삭제되지 않습니다.")
        End If
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If MessageBox.Show("*** 필 독 ***" & vbCrLf & _
                        "악성으로 분류한 기준은 아래 같습니다. " & vbCrLf & _
                        "(그리드 딜리버리, 툴바, 멀웨어, 애드온, 스폰서, 바로가기, 기타 등등..)" & vbCrLf & _
                        "                                            " & vbCrLf & _
                        "삭제여부를 본인이 선택할수있습니다. " & vbCrLf & _
                        "(일부 프로그램은 삭제 동의없이 바로 진행되는것도 있습니다.) " & vbCrLf & _
                        "제거가 제대로 되지 않으면 관리자 권한으로 실행해 주세요.  " & vbCrLf & _
                        "                                            " & vbCrLf & _
                        "설치된 악성 프로그램의 검사 또는 제거를 원하십니까?" & vbCrLf, _
                        "**** 필 독 ****", _
                        MessageBoxButtons.YesNo, _
                        MessageBoxIcon.Question) _
                    = DialogResult.Yes Then
            Me.Show()
        Else
            Application.Exit()
        End If

    End Sub

    Private Sub btnInfo_Click(sender As Object, e As EventArgs) Handles btnInfo.Click
        MessageBox.Show("네트워크에 접속되어 있는 사용자 컴퓨터 간에 " & vbCrLf & _
                        "데이터를 주고받게 함으로써 하나의 콘텐츠를 " & vbCrLf & _
                        "다수의 사용자가 효율적으로 이용할 수 있는 기술." & vbCrLf & _
                        "                                            " & vbCrLf & _
                        "동영상을 본 사용자 컴퓨터에 데이터를 저장시키고 " & vbCrLf & _
                        "다른 사람들이 같은 동영상을 볼 때 그 자료를 활용하는 방식이다. " & vbCrLf & _
                        "                                            " & vbCrLf & _
                        "따라서 회사 측에서는 동영상을 분산 저장할 수 있기 때문에 " & vbCrLf & _
                        "데이터를 빠른 속도로 보낼 수 있지만 사용자는 " & vbCrLf & _
                        "컴퓨터 용량을 그만큼 손실하여 " & vbCrLf & _
                        "컴퓨터 속도가 느려지는 단점이 있다. " & vbCrLf & _
                        "                                            " & vbCrLf & _
                        "- 네이버 지식사전 인용-" & vbCrLf, _
                        "그리드 딜리버리(Grid Delivery)란??", _
                        MessageBoxButtons.OK, _
                        MessageBoxIcon.Information)
    End Sub

    Private Sub btnGoToWebsite_Click(sender As Object, e As EventArgs) Handles btnGoToWebsite.Click
        System.Diagnostics.Process.Start("http://www.raonpia.com")
    End Sub

    Private Sub btnShutdown_Click(sender As Object, e As EventArgs) Handles btnShutdown.Click
        Application.Exit()
    End Sub
End Class