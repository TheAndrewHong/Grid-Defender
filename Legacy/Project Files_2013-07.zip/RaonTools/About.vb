﻿Public NotInheritable Class frmAbout
    Private Sub frmAbout_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.Escape Then
            Me.Close()
        End If
    End Sub

    Private Sub frmAbout_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lblVer.Text = My.Settings.Ver_Info
        lblLastUpdated.Text = My.Settings.Last_Updated
    End Sub
End Class
